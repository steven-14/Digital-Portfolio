This digital portfolio contains examples of web developement I made and my main qualifications. It is published here: https://steven-14.github.io/Digital-Portfolio/

